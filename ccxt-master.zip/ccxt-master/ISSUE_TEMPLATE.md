ATTENTION!!!

MUST READ THIS BEFORE SUBMITTING ISSUES:

https://github.com/ccxt/ccxt/blob/master/CONTRIBUTING.md#how-to-submit-an-issue

- OS:
- Programming Language version:
- CCXT version:
- Exchange:
- Method:

<?php

namespace ccxt;

class InsufficientFunds extends ExchangeError {

}